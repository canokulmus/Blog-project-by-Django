
#  manage.py runserver    - server çalıştırma

# manage.py createsuperuser - superuser oluşturma

#  manage.py startapp <appName>  - app oluşturma

# python manage.py makemigrations - yeni model eklendiğinde çalıştırmamız lazım 
 
# python manage.py migrate - migrationstakileri uygular

# python manage.py shell - django modüllerinin ekli olduğu python terminalini açar

# python manage.py collectstatic